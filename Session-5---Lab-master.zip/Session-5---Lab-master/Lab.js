//Bai 1:
// let n = Math.random();
// console.log(n);


// Bai 2
// let arr = [1, 3, 5, 7, 9, 6, 11, 15, 14];
// let a = arr[Math.floor(Math.random() * 10)];
// console.log(a);


// Bai 3
// Hiếu
let name = [];
let count = 0;
let flag = true;
let flag2;
let score;
let rankingScore = [];
let rankingResult = '';
let flag3;
// khai báo bank va bankDapAn của anh Nhẫn
let bank = [];
let question1 = 'Có bao nhiêu chấm trên 2 con xúc xắc ? \n A.42 \nB.30 \nC.38 \nD.36';
let question2 = 'Bệnh gì bác sĩ bó tay? \nA.Ung thư \nB.Gãy tay \nC.Thiếu máu \nD.Máu D';
let question3 = 'Bạn làm gì đầu tiên khi thức dậy? \nA.Vươn vai \nB.Mở mắt \nC.Ngáp \nD.Vệ sinh';
let question4 = 'Con gì càng to càng nhỏ? \nA.Con đường \nB.Con cua \nC.Con mắt \nD.Con cáo';
let question5 = 'Con chuột nào sợ mèo? \nA.Mickey \nB.Jerry \nC.Tất cả chuột \nD.Chuột máy tính';
let question6 = 'Huyện đảo Phú Quốc thuộc tỉnh nào? \nA.Trà Vinh \nB.An Giang \nC.Cà Mau \nD.Kiên Giang';
let question7 = 'Cầu thủ nào đạt danh hiệu Quả Bóng Vàng năm 2006? \nA.CaFu \nB.Roberto Carlos \nC.Fabio Canavaro \nD.Ronaldinho';
let question8 = 'Sóng điện từ có bước sóng từ 10m-100m gọi là sóng gì? \nA.Sóng ngắn \nB.Sóng siêu ngắn \nC.Sóng dài \nD.Sóng siêu dài';
let question9 = 'Trung bình, một người đàn ông có bao nhiêu sinh nhật? \nA.1 \nB.10 \nC.60 \nD.70';
let question10 = 'Con người có bao nhiêu cặp nhiễm sắc thể? \nA.20 \nB.25 \nC.23 \nD.21';
bank.push(question1, question2, question3, question4, question5, question6, question7, question8, question9, question10);
let bankDapAn = ['A', 'a', 'B', 'b', 'B', 'b', 'B', 'b', 'C', 'c', 'D', 'd', 'C', 'c', 'A', 'a', 'A', 'a', 'C', 'c'];
// đoạn chấm điểm của anh Vinh
while (flag) {
    flag2 = true;
    score = 0;
    // tạo tên người chơi thứ n với biến đếm count
    name[count] =  prompt("Please enter your name!");
    alert(`Welcome ${name[count]} to our mini game. The regulation is on the next alert. Hope you enjoy!`);
    alert(`Hello ${name[count]}! There will be 5 questions. You only have one\nchance to answer a question at once. You will get 20 points\nfor a correct answer and 0 point for the wrong one. Let's start!`);
    // Lựa chọn 1 số ngẫu nhiên từ 0 - 9 để chọn 5 câu hỏi từ bank
    let a = Math.floor(Math.random() * 5);
    for (let i = a; i < a + 5; i++){
        //show và nhập đáp án
        let answer = prompt(bank[i]); 
        // kiểm tra xem người dùng có nhập đúng available answer không
        flag3 = true;
        while(flag3){
        if(answer == 'A' || answer == 'a' || answer == 'B' || answer == 'b' || answer == 'C' || answer == 'c' || answer == 'D' || answer == 'd'){
        // tính điểm
        flag3 = false;
        if (answer == bankDapAn[2*i] || answer == bankDapAn[2*i + 1]){
            score += 20;
            alert('Bạn đã trả lời đúng. \nĐiểm hiện tại của bạn là: ' + score);
        }
        else {
        alert('Bạn đã trả lời sai \nĐáp án đúng là:' + bankDapAn[2*i] + '\nĐiểm hiện tại của bạn là: ' + score);
        }
        }
        else{
            answer = prompt(`${bank[i]}\nHãy chọn một trong 4 đáp án A, B, C, D`);
        }
        }
    }
    alert('Bạn đã hoàn thành bài thi, số điểm của bạn là:' + score)
    // lưu ranking score - Hiếu
    rankingScore.push(score);
    // Kiểm tra người dùng muốn chơi tiếp hay không - Hiếu
    let choiTiep = prompt("Your result is wonderful. \n Do you want to try this game again? (Y/N)");
    while (flag2) {
        if(choiTiep == "Y" || choiTiep == 'y'){
            flag2 = false;
            count++;
        }
        else if(choiTiep == "N" || choiTiep == 'n'){
            flag2 = false;
            flag = false;
            // sắp xếp tên và score để ranking - Hiếu
            for (let i = 0; i < rankingScore.length; i++) {
                for (let j = i + 1; j < rankingScore.length; j++) {
                    if(rankingScore[j] > rankingScore[i]){
                        let temp = rankingScore[j];
                        rankingScore[j] = rankingScore[i];
                        rankingScore[i] = temp;
                        console.log(rankingScore[i]);
                        let temp2 = name[j];
                        name[j] = name[i];
                        name[i] = temp2;
                        console.log(name[i]);
                    }
                }
            }
            for (let i = 0; i < rankingScore.length ; i++) {
                rankingResult += `${i+1}. ${name[i]} get ${rankingScore[i]}\n`;
            }
            alert(rankingResult);
    }
        else {
            choiTiep = prompt("Do you want to try this game again? \n Please enter Y/N.");
        }
    }
}