const map_img = "https://vignette.wikia.nocookie.net/leagueoflegends/images/5/53/Summoner%27s_Rift_Update_Map.png/revision/latest?cb=20170223053555";
let body = document.getElementById('body2');
body.insertAdjacentHTML('afterbegin', `<img src = ${map_img}></img>`);