const url = "https://5f749eab1cf3c900161cd568.mockapi.io/api/champion-data/";
let counterAndEncounter = document.getElementById("counter-encounter");
let counter = document.getElementsByClassName("counter");
let encounter = document.getElementsByClassName("encounter");
let champion = document.getElementsByClassName("champion");
let topLane = document.getElementById("top-lane");
let midLane = document.getElementById("mid-lane");
let jungleLane = document.getElementById("jungle-lane");
let adLane = document.getElementById("ad-lane");
let spLane = document.getElementById("sp-lane");
let btntop = document.getElementById("btn-top");
let btnmid = document.getElementById("btn-mid");
let btnjungle = document.getElementById("btn-jungle");
let btnad = document.getElementById("btn-ad");
let btnsp = document.getElementById("btn-sp");
let body2 = document.getElementById("body2");



// 5 functions create dưới đây có chức năng: thêm thông tin tướng vào html nhờ fectch(API)
// Đồng thời cho phép hiển thị top 3 tướng đứng đầu và 3 tướng đứng bét
// Cho phép hiển thị các kèo matchup khi bấm vào nút tên
async function createTop(){
    let topLaneString = "";
    let res = await fetch(url);
    let data = await res.json();
    for (let i = 1; i <= 6; i++) {
        topLaneString = "";
        topLaneString += `
        <tr>
            <td>${data[i-1].rank}</td>
            <td><img src=${data[i-1].img} alt="img"> <button class = "champion">${data[i-1].champion}</button></td>
            <td>${data[i-1].role}</td>
            <td>${data[i-1].winPercent}</td>
            <td>${data[i-1].playPercent}</td>
            <td>${data[i-1].banRate}</td>
            <td>${data[i-1].kills}</td>
            <td>${data[i-1].deadths}</td>
            <td>${data[i-1].assists}</td>
        </tr>
        `
        for (let j = 0; j < 5; j++) {
            counter[i-1].insertAdjacentHTML("beforeend", createCounter(data,i,j));
        }
        counter[i-1].style.display = "none";
        for (let j = 0; j < 5; j++) {
            encounter[i-1].insertAdjacentHTML("beforeend", createenCounter(data,i,j));
        }
        encounter[i-1].style.display = "none";
        topLane.insertAdjacentHTML("beforeend", topLaneString);
        champion = document.getElementsByClassName("champion");
        champion[i-1].addEventListener("click", () => {
            body2.style.display = "none";
            counter[i-1].style.display = "block";
            encounter[i-1].style.display = "block";
        });
    }
    topLane.style.display = "none";
    btntop.addEventListener("click", () => {
        midLane.style.display = "none";
        jungleLane.style.display = "none";
        adLane.style.display = "none";
        spLane.style.display = "none";
        if (topLane.style.display === "none") {
            topLane.style.display = "block";
        } else {
            topLane.style.display = "none";
        }
        })

}
async function createMid(){
    let midLaneString = "";
    let res = await fetch(url);
    let data = await res.json();
    for (let i = 7; i <= 12; i++) {
        midLaneString = "";
        midLaneString += `
        <tr>
            <td>${data[i-1].rank}</td>
            <td><img src=${data[i-1].img} alt="img"> <button class = "champion">${data[i-1].champion}</button></td>
            <td>${data[i-1].role}</td>
            <td>${data[i-1].winPercent}</td>
            <td>${data[i-1].playPercent}</td>
            <td>${data[i-1].banRate}</td>
            <td>${data[i-1].kills}</td>
            <td>${data[i-1].deadths}</td>
            <td>${data[i-1].assists}</td>
        </tr>
        `
        for (let j = 0; j < 5; j++) {
            counter[i-1].insertAdjacentHTML("beforeend", createCounter(data,i,j));
        }
        counter[i-1].style.display = "none";
        for (let j = 0; j < 5; j++) {
            encounter[i-1].insertAdjacentHTML("beforeend", createenCounter(data,i,j));
        }
        encounter[i-1].style.display = "none";
        midLane.insertAdjacentHTML("beforeend", midLaneString);
        champion = document.getElementsByClassName("champion");
        champion[i-1].addEventListener("click", () => {
            body2.style.display = "none";
            counter[i-1].style.display = "block";
            encounter[i-1].style.display = "block";
        });
    }
    midLane.style.display = "none";
    btnmid.addEventListener("click", () => {
        topLane.style.display = "none";
        jungleLane.style.display = "none";
        adLane.style.display = "none";
        spLane.style.display = "none";
        if (midLane.style.display === "none") {
            midLane.style.display = "block";
        } else {
            midLane.style.display = "none";
        }
        })
}
async function createJungle(){
    let jungleLaneString = "";
    let res = await fetch(url);
    let data = await res.json();
    for (let i = 13; i <= 18; i++) {
        jungleLaneString = "";
        jungleLaneString += `
        <tr>
            <td>${data[i-1].rank}</td>
            <td><img src=${data[i-1].img} alt="img"> <button class = "champion"">${data[i-1].champion}</button></td>
            <td>${data[i-1].role}</td>
            <td>${data[i-1].winPercent}</td>
            <td>${data[i-1].playPercent}</td>
            <td>${data[i-1].banRate}</td>
            <td>${data[i-1].kills}</td>
            <td>${data[i-1].deadths}</td>
            <td>${data[i-1].assists}</td>
        </tr>
        `
        for (let j = 0; j < 5; j++) {
            counter[i-1].insertAdjacentHTML("beforeend", createCounter(data,i,j));
        }
        counter[i-1].style.display = "none";
        for (let j = 0; j < 5; j++) {
            encounter[i-1].insertAdjacentHTML("beforeend", createenCounter(data,i,j));
        }
        encounter[i-1].style.display = "none";
        jungleLane.insertAdjacentHTML("beforeend", jungleLaneString);
        champion = document.getElementsByClassName("champion");
        champion[i-1].addEventListener("click", () => {
            body2.style.display = "none";
            counter[i-1].style.display = "block";
            encounter[i-1].style.display = "block";
        });
    }
    jungleLane.style.display = "none";
    btnjungle.addEventListener("click", () => {
        midLane.style.display = "none";
        topLane.style.display = "none";
        adLane.style.display = "none";
        spLane.style.display = "none";
        if (jungleLane.style.display === "none") {
            jungleLane.style.display = "block";
        } else {
            jungleLane.style.display = "none";
        }
        })
}
async function createAd(){
    let adLaneString = "";
    let res = await fetch(url);
    let data = await res.json();
    for (let i = 19; i <= 24; i++) {
        adLaneString = "";
        adLaneString += `
        <tr>
            <td>${data[i-1].rank}</td>
            <td><img src=${data[i-1].img} alt="img"> <button class = "champion">${data[i-1].champion}</button></td>
            <td>${data[i-1].role}</td>
            <td>${data[i-1].winPercent}</td>
            <td>${data[i-1].playPercent}</td>
            <td>${data[i-1].banRate}</td>
            <td>${data[i-1].kills}</td>
            <td>${data[i-1].deadths}</td>
            <td>${data[i-1].assists}</td>
        </tr>
        `
        for (let j = 0; j < 5; j++) {
            counter[i-1].insertAdjacentHTML("beforeend", createCounter(data,i,j));
        }
        counter[i-1].style.display = "none";
        for (let j = 0; j < 5; j++) {
            encounter[i-1].insertAdjacentHTML("beforeend", createenCounter(data,i,j));
        }
        encounter[i-1].style.display = "none";
        adLane.insertAdjacentHTML("beforeend", adLaneString);
        champion = document.getElementsByClassName("champion");
        champion[i-1].addEventListener("click", () => {
            body2.style.display = "none";
            counter[i-1].style.display = "block";
            encounter[i-1].style.display = "block";
        });
    }
    adLane.style.display = "none";
    btnad.addEventListener("click", () => {
        midLane.style.display = "none";
        jungleLane.style.display = "none";
        topLane.style.display = "none";
        spLane.style.display = "none";
        if (adLane.style.display === "none") {
            adLane.style.display = "block";
        } else {
            adLane.style.display = "none";
        }
        })
}
async function createSp(){
    let spLaneString = "";
    let res = await fetch(url);
    let data = await res.json();
    for (let i = 25; i <= 30; i++) {
        spLaneString = "";
        spLaneString += `
        <tr>
            <td>${data[i-1].rank}</td>
            <td><img src=${data[i-1].img} alt="img"> <button class = "champion">${data[i-1].champion}</button></td>
            <td>${data[i-1].role}</td>
            <td>${data[i-1].winPercent}</td>
            <td>${data[i-1].playPercent}</td>
            <td>${data[i-1].banRate}</td>
            <td>${data[i-1].kills}</td>
            <td>${data[i-1].deadths}</td>
            <td>${data[i-1].assists}</td>
        </tr>
        `
        for (let j = 0; j < 5; j++) {
            counter[i-1].insertAdjacentHTML("beforeend", createCounter(data,i,j));
        }
        counter[i-1].style.display = "none";
        for (let j = 0; j < 5; j++) {
            encounter[i-1].insertAdjacentHTML("beforeend", createenCounter(data,i,j));
        }
        encounter[i-1].style.display = "none";
        spLane.insertAdjacentHTML("beforeend", spLaneString);
        champion = document.getElementsByClassName("champion");
        champion[i-1].addEventListener("click", () => {
            body2.style.display = "none";
            counter[i-1].style.display = "block";
            encounter[i-1].style.display = "block";
        });
    }
    spLane.style.display = "none";
    btnsp.addEventListener("click", () => {
        midLane.style.display = "none";
        jungleLane.style.display = "none";
        adLane.style.display = "none";
        topLane.style.display = "none";
        if (spLane.style.display === "none") {
            spLane.style.display = "block";
        } else {
            spLane.style.display = "none";
        }
        })
}
// chỗ này khởi tạo 5 functions create thôi này
createTop();
createMid();
createJungle();
createAd();
createSp();


// chỗ này khởi tạo hàm để hiển thị kèo tướng Match up
function createCounter(counter,i,j){
    return `
        <div class="counter-champion">
            <img src="${counter[i-1].counter[j].img}" alt="img">
            <p>${counter[i-1].counter[j].champion}</p>
            <div class="progress">
            <div class="progress-bar" style="width:${counter[i-1].counter[j].winRate}"></div>
            </div>
            <p>${counter[i-1].counter[j].winRate}</p>
        </div>
    `
}

function createenCounter(encounter,i,j){
    return `
        <div class="encounter-champion">
            <img src="${encounter[i-1].encounter[j].img}" alt="img">
            <p>${encounter[i-1].encounter[j].champion}</p>
            <div class="progress">
            <div class="progress-bar" style="width:${encounter[i-1].encounter[j].winRate}"></div>
            </div>
            <p>${encounter[i-1].encounter[j].winRate}</p>
        </div>
    `
}

