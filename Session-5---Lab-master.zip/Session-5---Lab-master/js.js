let name = prompt("Please enter your name!");
alert(`Welcome ${name} to our mini game. The regulation is on the next alert. Hope you enjoy!`);
alert(`Hello ${name}! There will be 3 questions. You only have one 
chance to answer a question at once. You will get 30 points 
for a correct answer and 0 point for the wrong one. Let's start!`)
let flag = true;
let flag2;
let score;
// khai báo bank của anh Nhẫn
while(flag){
    flag2 = true;
    score = 0
    for (let i =0; i<3; i++ ){
        let b = Math.floor(Math.random() * 5) 
        let a = bank[b]

        let answer = prompt(a) //show và nhập đáp án
        if (answer == )
        //check đáp án if 
        //khi đáp án đúng thì chúc mừng và công bố điểm hiện tại +=30
        //else sai thì chia buồn và đáp án đúng là, công bố điểm hiện tại 
        else 
        alert('Bạn đã trả lời sai, đáp án đúng là:' + ... + '\n' "Điểm hiện tại của bạn là: " + score)
    }
    //bạn đã trẻ lời đúng ... câu, điểm của bạn là ...
    alert ('Bạn đã trả lời đúng: ' + số câu + ", điểm của bạn là:" + score)

    // đoạn chấm điểm của anh Vinh